#include <Arduino.h>
#ifndef LCD12864RSPI_h
#define LCD12864RSPI_h
#include <avr/pgmspace.h>
#include <inttypes.h>


class LCD12864RSPI {
typedef unsigned char uchar;

public:

LCD12864RSPI();

//Thaumy添加的
void PinSet(int latchPin,int clockPin,int dataPin);
//

void Initialise(void);
void delayns(void);

void WriteByte(int dat);
void WriteCommand(int CMD);
void WriteData(int CMD);


void ClearLCD(void);
void DisplayString(int X,int Y,uchar *ptr,int dat);
void DisplaySig(int M,int N,int sig);
void DrawFullScreen(uchar *p);

int delaytime;
int DEFAULTTIME;

/*
int latchPin = 8;
int clockPin = 3;
int dataPin = 9;
*/

};
extern LCD12864RSPI LCD;    
#endif
